@extends('backend.layouts.app')

@section('title', 'Dashboard')

@section('page-icon', 'pe-7s-car')

@section('page-title', 'Dashboard')

@section('page-description', 'Admin > Dashboard')

@section('content')

@endsection
